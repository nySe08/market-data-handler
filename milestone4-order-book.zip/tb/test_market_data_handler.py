"""End-to-end test: raw Ethernet frames in -> top of book out.
Also MEASURES the latency of the whole pipeline."""
import random

import cocotb
from cocotb.clock import Clock
from cocotb.triggers import ClockCycles, RisingEdge, ReadOnly
from cocotb.utils import get_sim_time

from packet_gen import build_frame, build_message, decode_message, SIDE_BID
from ref_model import OrderBook

CLK_NS = 4   # 250 MHz


async def setup(dut):
    cocotb.start_soon(Clock(dut.clk, CLK_NS, unit="ns").start())
    dut.rst.value = 1
    dut.s_tvalid.value = 0
    dut.s_tdata.value = 0
    dut.s_tlast.value = 0
    await ClockCycles(dut.clk, 2)
    dut.rst.value = 0


def read_top(dut):
    return (int(dut.best_bid_px.value), int(dut.best_bid_qty.value),
            int(dut.best_ask_px.value), int(dut.best_ask_qty.value))


async def send_frame(dut, frame: bytes, mark_byte: int | None = None) -> float | None:
    """Drive a frame. If mark_byte is given, return the sim time (ns) at which
    that byte was put on the input (= start of the cycle it is presented in)."""
    t_mark = None
    for i, b in enumerate(frame):
        dut.s_tvalid.value = 1
        dut.s_tdata.value = b
        dut.s_tlast.value = int(i == len(frame) - 1)
        if i == mark_byte:
            t_mark = get_sim_time(unit="ns")
        await RisingEdge(dut.clk)
    dut.s_tvalid.value = 0
    dut.s_tlast.value = 0
    return t_mark


async def collect_tob(dut, out: list):
    """Monitor: record (time, top of book) at every tob_valid pulse."""
    while True:
        await RisingEdge(dut.clk)
        await ReadOnly()
        if dut.tob_valid.value == 1:
            out.append((get_sim_time(unit="ns"), read_top(dut)))


@cocotb.test()
async def measure_latency(dut):
    """Cycles from the last message byte appearing on the input to tob_valid
    appearing on the output. 3 register stages -> expect 3 cycles."""
    await setup(dut)
    events = []
    cocotb.start_soon(collect_tob(dut, events))

    msg = build_message(SIDE_BID, price=10_000, qty=300)
    frame = build_frame([msg])               # 58 bytes + 2 padding
    last_msg_byte = 42 + len(msg) - 1        # index 57

    t_in = await send_frame(dut, frame, mark_byte=last_msg_byte)
    await ClockCycles(dut.clk, 5)

    assert len(events) == 1, f"expected 1 tob event, got {len(events)}"
    t_out, top = events[0]
    assert top == (10_000, 300, 0, 0)
    cycles = round((t_out - t_in) / CLK_NS)
    dut._log.info(f"LATENCY: {cycles} cycles = {cycles * CLK_NS} ns @ {1000 // CLK_NS} MHz")
    assert cycles == 3, f"expected 3 cycles, measured {cycles}"


@cocotb.test()
async def random_end_to_end(dut):
    """1,000 random frames (some invalid). Every tob_valid event must match
    the reference model, in order."""
    await setup(dut)
    events = []
    cocotb.start_soon(collect_tob(dut, events))

    rng = random.Random(99)
    model = OrderBook(n=8)
    expected = []
    seq = 0

    for _ in range(1000):
        msgs = []
        for _ in range(rng.randint(1, 4)):
            is_bid = rng.random() < 0.5
            price = rng.randint(9_990, 10_010)
            qty = 0 if rng.random() < 0.3 else rng.randint(1, 1000)
            msgs.append(build_message(0x42 if is_bid else 0x53, price, qty, seq=seq))
            seq += 1
        frame = build_frame(msgs)

        if rng.random() < 0.2:                       # invalid frame: wrong port
            frame = build_frame(msgs, dst_port=1234)
        else:
            for m in msgs:
                d = decode_message(m)
                if model.apply(d["side"] == "B", d["price"], d["qty"]):
                    expected.append(model.top())

        await send_frame(dut, frame)

    await ClockCycles(dut.clk, 5)
    got = [top for _, top in events]
    assert len(got) == len(expected), f"{len(got)} tob events, expected {len(expected)}"
    for i, (g, e) in enumerate(zip(got, expected)):
        assert g == e, f"event {i}: got {g}, expected {e}"
    dut._log.info(f"{len(expected)} top-of-book updates match the reference model")
