"""
Golden reference model of the order book, in plain Python.

The RTL must behave EXACTLY like this. Tests apply the same messages to both
and compare. Keep it simple and obviously correct: clarity beats speed here.
"""


class BookSide:
    def __init__(self, is_bid: bool, n: int = 8):
        self.is_bid = is_bid
        self.n = n
        self.levels: dict[int, int] = {}   # price -> qty

    def _sorted_prices(self):
        return sorted(self.levels, reverse=self.is_bid)   # best first

    def best(self) -> tuple[int, int]:
        """(price, qty) of the best level, (0, 0) if empty."""
        if not self.levels:
            return (0, 0)
        p = self._sorted_prices()[0]
        return (p, self.levels[p])

    def apply(self, price: int, qty: int) -> None:
        if price in self.levels:
            if qty == 0:
                del self.levels[price]           # remove
            else:
                self.levels[price] = qty         # update
            return
        if qty == 0:
            return                               # remove unknown price: ignore
        if len(self.levels) < self.n:
            self.levels[price] = qty             # insert, room left
            return
        worst = self._sorted_prices()[-1]
        better = price > worst if self.is_bid else price < worst
        if better:                               # insert, evict the worst
            del self.levels[worst]
            self.levels[price] = qty
        # else: worse than all N levels -> ignore


class OrderBook:
    def __init__(self, n: int = 8):
        self.bid = BookSide(True, n)
        self.ask = BookSide(False, n)

    def top(self) -> tuple[int, int, int, int]:
        return (*self.bid.best(), *self.ask.best())

    def apply(self, is_bid: bool, price: int, qty: int) -> bool:
        """Apply one message. Returns True if the top of book changed."""
        before = self.top()
        (self.bid if is_bid else self.ask).apply(price, qty)
        return self.top() != before
