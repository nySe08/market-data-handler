// Top level: raw Ethernet frame bytes in -> top of book out.
//
//   s_* bytes -> eth_ip_udp_parser -> msg_decoder -> order_book -> tob_*
//                  (1 cycle)           (1 cycle)      (1 cycle)
module market_data_handler #(
    parameter logic [15:0] UDP_PORT = 16'd26400,
    parameter int          N        = 8
) (
    input  logic        clk,
    input  logic        rst,

    input  logic        s_tvalid,
    input  logic [7:0]  s_tdata,
    input  logic        s_tlast,

    output logic        tob_valid,
    output logic [31:0] best_bid_px,
    output logic [31:0] best_bid_qty,
    output logic [31:0] best_ask_px,
    output logic [31:0] best_ask_qty
);

    // parser -> decoder
    logic       p_tvalid, p_tlast;
    logic [7:0] p_tdata;

    // decoder -> book
    logic        msg_valid, msg_is_bid;
    logic [15:0] msg_instrument;   // single instrument in v1 (not used yet)
    logic [31:0] msg_price, msg_qty, msg_seq;

    eth_ip_udp_parser #(.UDP_PORT(UDP_PORT)) u_parser (
        .clk, .rst,
        .s_tvalid, .s_tdata, .s_tlast,
        .m_tvalid (p_tvalid), .m_tdata (p_tdata), .m_tlast (p_tlast)
    );

    msg_decoder u_decoder (
        .clk, .rst,
        .s_tvalid (p_tvalid), .s_tdata (p_tdata), .s_tlast (p_tlast),
        .msg_valid, .msg_is_bid, .msg_instrument,
        .msg_price, .msg_qty, .msg_seq
    );

    order_book #(.N(N)) u_book (
        .clk, .rst,
        .msg_valid, .msg_is_bid, .msg_price, .msg_qty,
        .tob_valid, .best_bid_px, .best_bid_qty, .best_ask_px, .best_ask_qty
    );

endmodule
